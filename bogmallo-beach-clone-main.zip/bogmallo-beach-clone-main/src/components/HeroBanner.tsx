
import React from 'react';
import { Phone, Calendar, MapPin } from 'lucide-react';
import { Button } from '@/components/ui/button';

const HeroBanner = () => {
  const handleCall = () => {
    window.open('tel:08619273819', '_self');
  };

  const handleBookNow = () => {
    document.getElementById('rooms')?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section id="home" className="relative min-h-screen overflow-hidden">
      {/* Background with parallax effect */}
      <div className="absolute inset-0 parallax">
        <div 
          className="parallax-layer parallax-layer-back bg-cover bg-center bg-no-repeat"
          style={{
            backgroundImage: `url('https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80')`
          }}
        />
        <div className="parallax-layer parallax-layer-base bg-gradient-to-br from-resort-primary/80 via-resort-secondary/70 to-resort-ocean/80" />
        
        {/* Floating elements */}
        <div className="absolute top-20 left-10 w-20 h-20 bg-resort-gold/10 rounded-full blur-xl animate-bounce-subtle" />
        <div className="absolute bottom-32 right-16 w-32 h-32 bg-resort-coral/10 rounded-full blur-2xl animate-bounce-subtle" style={{ animationDelay: '1s' }} />
        <div className="absolute top-1/3 right-1/4 w-16 h-16 bg-resort-teal/10 rounded-full blur-lg animate-bounce-subtle" style={{ animationDelay: '2s' }} />
      </div>
      
      <div className="relative z-10 container mx-auto px-4 min-h-screen flex items-center">
        <div className="max-w-4xl text-white">
          {/* Main headline with luxury text effect */}
          <div className="mb-8 animate-fade-in">
            <h1 className="text-6xl md:text-8xl font-bold mb-6 leading-tight">
              <span className="block luxury-text">Welcome to</span>
              <span className="block text-resort-gold font-playfair italic text-7xl md:text-9xl">
                Bogmallo Beach
              </span>
              <span className="block text-5xl md:text-7xl font-light">Resort</span>
            </h1>
          </div>
          
          {/* Elegant subtitle */}
          <div className="mb-12 animate-fade-in" style={{ animationDelay: '0.3s' }}>
            <p className="text-2xl md:text-3xl mb-4 text-gray-100 font-light leading-relaxed">
              Experience unparalleled luxury and tranquility
            </p>
            <p className="text-xl md:text-2xl text-resort-gold font-medium">
              at Goa's most prestigious beachfront destination
            </p>
          </div>

          {/* Location and contact info cards */}
          <div className="grid md:grid-cols-2 gap-6 mb-12 animate-fade-in" style={{ animationDelay: '0.6s' }}>
            <div className="glass-effect rounded-2xl p-6 luxury-shadow">
              <div className="flex items-center text-white mb-2">
                <MapPin className="w-6 h-6 mr-3 text-resort-gold" />
                <span className="text-lg font-semibold">Bogmallo Beach, Goa</span>
              </div>
              <p className="text-gray-200 text-sm">Premium beachfront location</p>
            </div>
            
            <div className="glass-effect rounded-2xl p-6 luxury-shadow">
              <div className="flex items-center text-white mb-2">
                <Phone className="w-6 h-6 mr-3 text-resort-gold" />
                <span className="text-lg font-semibold">08619273819</span>
              </div>
              <p className="text-gray-200 text-sm">24/7 Concierge Service</p>
            </div>
          </div>

          {/* CTA buttons with enhanced styling */}
          <div className="flex flex-col sm:flex-row gap-6 animate-fade-in" style={{ animationDelay: '0.9s' }}>
            <Button
              onClick={handleBookNow}
              size="lg"
              className="button-luxury bg-gradient-to-r from-resort-gold via-resort-coral to-resort-gold text-white px-12 py-6 text-xl font-bold rounded-2xl shadow-button-glow border-2 border-resort-gold/50"
            >
              <Calendar className="w-6 h-6 mr-3" />
              Reserve Your Suite
            </Button>
            
            <Button
              onClick={handleCall}
              variant="outline"
              size="lg"
              className="glass-effect border-2 border-white/50 text-white hover:bg-white/20 px-12 py-6 text-xl font-semibold rounded-2xl transition-all duration-300 hover:scale-105"
            >
              <Phone className="w-6 h-6 mr-3" />
              Call Concierge
            </Button>
          </div>

          {/* Trust indicators */}
          <div className="mt-16 flex flex-wrap gap-8 opacity-80 animate-fade-in" style={{ animationDelay: '1.2s' }}>
            <div className="text-center">
              <div className="text-3xl font-bold text-resort-gold">25+</div>
              <div className="text-sm text-gray-300">Years of Excellence</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-resort-gold">★★★★★</div>
              <div className="text-sm text-gray-300">Luxury Resort</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-resort-gold">100%</div>
              <div className="text-sm text-gray-300">Guest Satisfaction</div>
            </div>
          </div>
        </div>
      </div>

      {/* Scroll indicator */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce-subtle">
        <div className="w-6 h-10 border-2 border-white/50 rounded-full flex justify-center">
          <div className="w-1 h-3 bg-white/70 rounded-full mt-2 animate-pulse"></div>
        </div>
      </div>
    </section>
  );
};

export default HeroBanner;
