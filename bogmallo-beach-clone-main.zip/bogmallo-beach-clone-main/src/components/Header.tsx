
import React, { useState } from 'react';
import { Phone, Menu, X } from 'lucide-react';
import { Button } from '@/components/ui/button';

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const handleCall = () => {
    window.open('tel:08619273819', '_self');
  };

  const handleWhatsApp = () => {
    window.open('https://wa.me/918619273819', '_blank');
  };

  return (
    <header className="bg-white shadow-lg sticky top-0 z-50">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-20">
          <div className="flex items-center">
            <h1 className="text-2xl font-bold text-resort-ocean">Bogmallo Beach Resort</h1>
          </div>
          
          <nav className="hidden md:flex items-center space-x-8">
            <a href="#home" className="text-gray-700 hover:text-resort-ocean transition-colors">Home</a>
            <a href="#rooms" className="text-gray-700 hover:text-resort-ocean transition-colors">Rooms</a>
            <a href="#amenities" className="text-gray-700 hover:text-resort-ocean transition-colors">Amenities</a>
            <a href="#contact" className="text-gray-700 hover:text-resort-ocean transition-colors">Contact</a>
          </nav>

          <div className="hidden md:flex items-center space-x-4">
            <Button
              onClick={handleCall}
              variant="outline"
              size="sm"
              className="text-resort-ocean border-resort-ocean hover:bg-resort-ocean hover:text-white"
            >
              <Phone className="w-4 h-4 mr-2" />
              Call Now
            </Button>
            <Button
              onClick={handleWhatsApp}
              className="bg-green-600 hover:bg-green-700 text-white"
              size="sm"
            >
              WhatsApp
            </Button>
          </div>

          <button
            className="md:hidden"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>

        {isMenuOpen && (
          <div className="md:hidden py-4 border-t">
            <nav className="flex flex-col space-y-4">
              <a href="#home" className="text-gray-700 hover:text-resort-ocean transition-colors">Home</a>
              <a href="#rooms" className="text-gray-700 hover:text-resort-ocean transition-colors">Rooms</a>
              <a href="#amenities" className="text-gray-700 hover:text-resort-ocean transition-colors">Amenities</a>
              <a href="#contact" className="text-gray-700 hover:text-resort-ocean transition-colors">Contact</a>
              <div className="flex space-x-4 pt-4">
                <Button
                  onClick={handleCall}
                  variant="outline"
                  size="sm"
                  className="text-resort-ocean border-resort-ocean hover:bg-resort-ocean hover:text-white"
                >
                  <Phone className="w-4 h-4 mr-2" />
                  Call Now
                </Button>
                <Button
                  onClick={handleWhatsApp}
                  className="bg-green-600 hover:bg-green-700 text-white"
                  size="sm"
                >
                  WhatsApp
                </Button>
              </div>
            </nav>
          </div>
        )}
      </div>
    </header>
  );
};

export default Header;
