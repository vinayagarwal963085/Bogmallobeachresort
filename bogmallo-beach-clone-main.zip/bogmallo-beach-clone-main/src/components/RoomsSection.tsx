
import React from 'react';
import { Phone, Users, Wifi, Car, Coffee, Waves } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader } from '@/components/ui/card';

const RoomsSection = () => {
  const rooms = [
    {
      id: 1,
      name: "Deluxe Sea View Room",
      image: "https://images.unsplash.com/photo-1649972904349-6e44c42644a7?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
      description: "Spacious room with stunning ocean views, private balcony, and modern amenities for the perfect beachfront experience.",
      amenities: ["Sea View", "AC", "WiFi", "Mini Bar", "Private Balcony"],
      price: "₹8,500",
      originalPrice: "₹10,000",
      maxGuests: "2 Adults",
      featured: false
    },
    {
      id: 2,
      name: "Premium Ocean Suite",
      image: "https://images.unsplash.com/photo-1721322800607-8c38375eef04?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
      description: "Luxurious suite with panoramic ocean views, separate living area, and premium furnishings for ultimate comfort.",
      amenities: ["Panoramic Sea View", "AC", "WiFi", "Mini Bar", "Living Area", "Jacuzzi"],
      price: "₹15,000",
      originalPrice: "₹18,000",
      maxGuests: "3 Adults",
      featured: true
    },
    {
      id: 3,
      name: "Garden View Room",
      image: "https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
      description: "Comfortable room overlooking lush tropical gardens with all essential amenities and peaceful ambiance.",
      amenities: ["Garden View", "AC", "WiFi", "Mini Bar", "Work Desk"],
      price: "₹6,500",
      originalPrice: "₹8,000",
      maxGuests: "2 Adults",
      featured: false
    },
    {
      id: 4,
      name: "Family Suite",
      image: "https://images.unsplash.com/photo-1649972904349-6e44c42644a7?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
      description: "Spacious family accommodation with separate bedrooms and living space, perfect for memorable family vacations.",
      amenities: ["2 Bedrooms", "AC", "WiFi", "Mini Bar", "Living Room", "Kitchenette"],
      price: "₹18,000",
      originalPrice: "₹22,000",
      maxGuests: "4 Adults + 2 Children",
      featured: false
    },
    {
      id: 5,
      name: "Presidential Villa",
      image: "https://images.unsplash.com/photo-1721322800607-8c38375eef04?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
      description: "Ultimate luxury with private pool, beach access, and personalized butler service for an exclusive experience.",
      amenities: ["Private Pool", "Beach Access", "Butler Service", "AC", "WiFi", "Full Kitchen"],
      price: "₹35,000",
      originalPrice: "₹45,000",
      maxGuests: "6 Adults",
      featured: true
    },
    {
      id: 6,
      name: "Standard Room",
      image: "https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
      description: "Cozy and comfortable room with all essential amenities at an affordable price, perfect for budget-conscious travelers.",
      amenities: ["AC", "WiFi", "Mini Bar", "Work Desk"],
      price: "₹4,500",
      originalPrice: "₹6,000",
      maxGuests: "2 Adults",
      featured: false
    }
  ];

  const handleBookRoom = (roomName: string) => {
    const message = `Hi! I would like to book the ${roomName}. Please provide availability and booking details.`;
    const whatsappUrl = `https://wa.me/918619273819?text=${encodeURIComponent(message)}`;
    window.open(whatsappUrl, '_blank');
  };

  const handleCallForBooking = () => {
    window.open('tel:08619273819', '_self');
  };

  return (
    <section id="rooms" className="py-24 section-gradient">
      <div className="container mx-auto px-4">
        {/* Enhanced section header */}
        <div className="text-center mb-20 animate-fade-in">
          <div className="inline-block mb-4">
            <span className="text-resort-gold text-lg font-semibold tracking-wider uppercase">Accommodation</span>
          </div>
          <h2 className="text-5xl md:text-6xl font-bold text-resort-primary mb-6 font-playfair">
            Luxury <span className="text-gradient">Rooms & Suites</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
            Choose from our selection of elegantly appointed accommodations, each designed to provide 
            the ultimate in comfort, luxury, and breathtaking views
          </p>
          
          {/* Decorative element */}
          <div className="mt-8 flex justify-center">
            <div className="w-24 h-1 bg-gradient-to-r from-resort-gold to-resort-coral rounded-full"></div>
          </div>
        </div>

        {/* Rooms grid with enhanced cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-10">
          {rooms.map((room, index) => (
            <Card 
              key={room.id} 
              className={`luxury-card card-hover-effect animate-fade-in ${room.featured ? 'ring-2 ring-resort-gold' : ''}`}
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              {/* Featured badge */}
              {room.featured && (
                <div className="absolute -top-4 left-1/2 transform -translate-x-1/2 z-10">
                  <div className="bg-gradient-to-r from-resort-gold to-resort-coral text-white px-6 py-2 rounded-full text-sm font-bold shadow-lg">
                    Most Popular
                  </div>
                </div>
              )}

              {/* Image container with overlay */}
              <div className="relative h-72 overflow-hidden rounded-t-2xl">
                <img
                  src={room.image}
                  alt={room.name}
                  className="w-full h-full object-cover transition-transform duration-500 hover:scale-110"
                />
                
                {/* Price overlay */}
                <div className="absolute top-4 right-4 glass-effect rounded-xl px-4 py-2">
                  <div className="text-white font-bold text-lg">{room.price}/night</div>
                  <div className="text-gray-300 line-through text-sm">{room.originalPrice}</div>
                </div>

                {/* Gradient overlay */}
                <div className="absolute inset-0 bg-gradient-to-t from-black/30 via-transparent to-transparent"></div>
              </div>
              
              <CardHeader className="pb-4">
                <h3 className="text-2xl font-bold text-resort-primary font-playfair">{room.name}</h3>
                <p className="text-gray-600 leading-relaxed">{room.description}</p>
              </CardHeader>

              <CardContent className="space-y-6">
                {/* Amenities with icons */}
                <div>
                  <p className="font-semibold text-resort-primary mb-3 text-lg">Premium Amenities</p>
                  <div className="grid grid-cols-2 gap-2">
                    {room.amenities.map((amenity, index) => (
                      <div key={index} className="flex items-center space-x-2">
                        <div className="w-2 h-2 bg-resort-gold rounded-full"></div>
                        <span className="text-sm text-gray-700">{amenity}</span>
                      </div>
                    ))}
                  </div>
                </div>
                
                {/* Guest capacity */}
                <div className="flex items-center text-resort-secondary bg-resort-cream/50 rounded-lg p-3">
                  <Users className="w-5 h-5 mr-2" />
                  <span className="font-medium">Accommodates {room.maxGuests}</span>
                </div>

                {/* Action buttons */}
                <div className="flex gap-3 pt-4">
                  <Button
                    onClick={() => handleBookRoom(room.name)}
                    className="flex-1 btn-primary text-base"
                  >
                    Reserve Now
                  </Button>
                  <Button
                    onClick={handleCallForBooking}
                    variant="outline"
                    className="btn-outline px-4"
                  >
                    <Phone className="w-5 h-5" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Concierge contact section */}
        <div className="text-center mt-20 animate-fade-in">
          <div className="luxury-card max-w-2xl mx-auto p-12">
            <div className="mb-6">
              <Waves className="w-16 h-16 text-resort-gold mx-auto mb-4" />
              <h3 className="text-3xl font-bold text-resort-primary mb-4 font-playfair">
                Personal Concierge Service
              </h3>
              <p className="text-gray-600 text-lg leading-relaxed mb-8">
                Our dedicated concierge team is available 24/7 to assist with reservations, 
                special requests, and creating unforgettable experiences tailored just for you.
              </p>
            </div>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button
                onClick={handleCallForBooking}
                size="lg"
                className="btn-primary text-lg"
              >
                <Phone className="w-6 h-6 mr-3" />
                Call 08619273819
              </Button>
              <Button
                onClick={() => window.open('https://wa.me/918619273819', '_blank')}
                size="lg"
                className="btn-secondary text-lg"
              >
                <Coffee className="w-6 h-6 mr-3" />
                WhatsApp Chat
              </Button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default RoomsSection;
