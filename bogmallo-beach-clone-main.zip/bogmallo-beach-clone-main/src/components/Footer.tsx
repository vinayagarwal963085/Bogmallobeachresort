
import React from 'react';
import { Phone, Mail, MapPin } from 'lucide-react';

const Footer = () => {
  const handleCall = () => {
    window.open('tel:08619273819', '_self');
  };

  const handleWhatsApp = () => {
    window.open('https://wa.me/918619273819', '_blank');
  };

  return (
    <footer className="bg-resort-ocean text-white py-12">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div>
            <h3 className="text-2xl font-bold mb-4 text-resort-gold">Bogmallo Beach Resort</h3>
            <p className="text-gray-300 mb-4">
              Experience luxury and tranquility at Goa's premier beachfront destination. 
              Your perfect beach vacation awaits.
            </p>
            <div className="flex space-x-4">
              <button
                onClick={handleCall}
                className="bg-resort-gold hover:bg-resort-gold/90 text-white px-4 py-2 rounded transition-colors"
              >
                Call Now
              </button>
              <button
                onClick={handleWhatsApp}
                className="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded transition-colors"
              >
                WhatsApp
              </button>
            </div>
          </div>

          <div>
            <h4 className="text-lg font-semibold mb-4 text-resort-gold">Quick Links</h4>
            <ul className="space-y-2 text-gray-300">
              <li><a href="#home" className="hover:text-white transition-colors">Home</a></li>
              <li><a href="#rooms" className="hover:text-white transition-colors">Rooms & Suites</a></li>
              <li><a href="#amenities" className="hover:text-white transition-colors">Amenities</a></li>
              <li><a href="#contact" className="hover:text-white transition-colors">Contact</a></li>
            </ul>
          </div>

          <div>
            <h4 className="text-lg font-semibold mb-4 text-resort-gold">Contact Info</h4>
            <div className="space-y-3 text-gray-300">
              <div className="flex items-center space-x-2">
                <Phone className="w-4 h-4" />
                <span>08619273819</span>
              </div>
              <div className="flex items-center space-x-2">
                <Mail className="w-4 h-4" />
                <span>info@bogmallobeachresort.com</span>
              </div>
              <div className="flex items-start space-x-2">
                <MapPin className="w-4 h-4 mt-1" />
                <span>Bogmallo Beach, Vasco da Gama,<br />Goa 403806, India</span>
              </div>
            </div>
          </div>
        </div>

        <div className="border-t border-gray-700 mt-8 pt-8 text-center text-gray-300">
          <p>&copy; 2024 Bogmallo Beach Resort. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
