
import React from 'react';
import { Phone, MapPin, Mail, Clock } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

const ContactSection = () => {
  const handleCall = () => {
    window.open('tel:08619273819', '_self');
  };

  const handleWhatsApp = () => {
    window.open('https://wa.me/918619273819', '_blank');
  };

  const handleEmail = () => {
    window.open('mailto:info@bogmallobeachresort.com', '_self');
  };

  return (
    <section id="contact" className="py-16 bg-resort-sand">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-resort-ocean mb-4">Contact Us</h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Get in touch with us for reservations, inquiries, or any assistance you need
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          <div className="space-y-6">
            <Card className="shadow-lg">
              <CardHeader>
                <CardTitle className="text-resort-ocean">Contact Information</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center space-x-3">
                  <Phone className="w-5 h-5 text-resort-ocean" />
                  <div>
                    <p className="font-semibold">Phone</p>
                    <p className="text-gray-600">08619273819</p>
                  </div>
                </div>
                
                <div className="flex items-center space-x-3">
                  <Mail className="w-5 h-5 text-resort-ocean" />
                  <div>
                    <p className="font-semibold">Email</p>
                    <p className="text-gray-600">info@bogmallobeachresort.com</p>
                  </div>
                </div>
                
                <div className="flex items-center space-x-3">
                  <MapPin className="w-5 h-5 text-resort-ocean" />
                  <div>
                    <p className="font-semibold">Address</p>
                    <p className="text-gray-600">Bogmallo Beach, Vasco da Gama, Goa 403806, India</p>
                  </div>
                </div>
                
                <div className="flex items-center space-x-3">
                  <Clock className="w-5 h-5 text-resort-ocean" />
                  <div>
                    <p className="font-semibold">Reception Hours</p>
                    <p className="text-gray-600">24/7 Available</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <Button
                onClick={handleCall}
                size="lg"
                className="bg-resort-ocean hover:bg-resort-ocean/90 text-white h-16"
              >
                <Phone className="w-6 h-6 mr-3" />
                <div className="text-left">
                  <div className="font-semibold">Call Now</div>
                  <div className="text-sm opacity-90">08619273819</div>
                </div>
              </Button>
              
              <Button
                onClick={handleWhatsApp}
                size="lg"
                className="bg-green-600 hover:bg-green-700 text-white h-16"
              >
                <div className="text-left">
                  <div className="font-semibold">WhatsApp</div>
                  <div className="text-sm opacity-90">+918619273819</div>
                </div>
              </Button>
            </div>
          </div>

          <div className="space-y-6">
            <Card className="shadow-lg">
              <CardHeader>
                <CardTitle className="text-resort-ocean">Quick Booking</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 mb-6">
                  Ready to book your stay? Contact us directly for the best rates and personalized service.
                </p>
                
                <div className="space-y-4">
                  <Button
                    onClick={handleWhatsApp}
                    className="w-full bg-resort-gold hover:bg-resort-gold/90 text-white h-12"
                  >
                    Book via WhatsApp
                  </Button>
                  
                  <Button
                    onClick={handleCall}
                    variant="outline"
                    className="w-full border-resort-ocean text-resort-ocean hover:bg-resort-ocean hover:text-white h-12"
                  >
                    Call for Booking
                  </Button>
                  
                  <Button
                    onClick={handleEmail}
                    variant="outline"
                    className="w-full border-resort-ocean text-resort-ocean hover:bg-resort-ocean hover:text-white h-12"
                  >
                    Email Inquiry
                  </Button>
                </div>
              </CardContent>
            </Card>

            <Card className="shadow-lg bg-resort-ocean text-white">
              <CardContent className="p-6">
                <h3 className="text-xl font-bold mb-4">Special Offers</h3>
                <p className="mb-4">Call us directly for exclusive deals and seasonal packages!</p>
                <div className="text-resort-gold font-semibold text-lg">
                  📞 08619273819
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ContactSection;
