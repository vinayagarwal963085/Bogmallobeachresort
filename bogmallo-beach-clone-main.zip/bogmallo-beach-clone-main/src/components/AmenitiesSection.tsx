
import React from 'react';
import { Card, CardContent } from '@/components/ui/card';

const AmenitiesSection = () => {
  const amenities = [
    {
      title: "Beachfront Location",
      description: "Direct access to pristine Bogmallo Beach with golden sand and crystal-clear waters",
      image: "https://images.unsplash.com/photo-1472396961693-142e6e269027?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80"
    },
    {
      title: "Swimming Pool",
      description: "Large outdoor swimming pool with pool bar and comfortable lounging areas",
      image: "https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80"
    },
    {
      title: "Spa & Wellness",
      description: "Full-service spa offering traditional Ayurvedic treatments and modern wellness therapies",
      image: "https://images.unsplash.com/photo-1649972904349-6e44c42644a7?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80"
    },
    {
      title: "Multi-Cuisine Restaurant",
      description: "Fine dining restaurant serving Goan, Indian, and international cuisine with ocean views",
      image: "https://images.unsplash.com/photo-1721322800607-8c38375eef04?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80"
    },
    {
      title: "Water Sports",
      description: "Exciting water sports activities including jet skiing, parasailing, and boat rides",
      image: "https://images.unsplash.com/photo-1469041797191-50ace28483c3?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80"
    },
    {
      title: "Conference Facilities",
      description: "Modern conference halls and meeting rooms equipped with latest technology",
      image: "https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80"
    }
  ];

  return (
    <section id="amenities" className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-resort-ocean mb-4">Resort Amenities</h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Discover our world-class facilities designed to make your stay unforgettable
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {amenities.map((amenity, index) => (
            <Card key={index} className="overflow-hidden shadow-lg hover:shadow-xl transition-shadow duration-300 animate-fade-in">
              <div className="relative h-48 overflow-hidden">
                <img
                  src={amenity.image}
                  alt={amenity.title}
                  className="w-full h-full object-cover transition-transform duration-300 hover:scale-105"
                />
              </div>
              <CardContent className="p-6">
                <h3 className="text-xl font-bold text-resort-ocean mb-3">{amenity.title}</h3>
                <p className="text-gray-600">{amenity.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};

export default AmenitiesSection;
